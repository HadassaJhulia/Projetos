import { Text, Image, ScrollView, Pressable, Alert, View, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

var Figma = require ('./assets/Figma.png');

export default function App() {
  return (
    <View style={styles.container}>
      <Image source={Figma}  style={styles.photo}/>
      <Text style={styles.paragraph}>
        Hadassa Jhulia Lima
      </Text>
      <View style={styles.red}>
        <ScrollView>
        <View style={styles.one}><Image source={Figma}/></View>
        <View style={styles.two}><Text style={styles.paragraph2}> O Figma e suas funcionalidades</Text></View>
        <View style={styles.one}><Image source={Figma}/></View>
        <View style={styles.two}><Text style={styles.paragraph2}> O Figma é uma ferramenta de design e prototipagem baseada em nuvem que tem ganhado popularidade entre designers e desenvolvedores.</Text></View>
        <View style={styles.one}><Image source={Figma}/></View>
        <View style={styles.two}><Text style={styles.paragraph2}>  Com sua interface intuitiva e recursos avançados, o Figma se tornou uma das ferramentas essenciais para profissionais que trabalham com design.</Text></View>
        <View style={styles.one}><Image source={Figma}/></View>
        <View style={styles.two}><Text style={styles.paragraph2}>  O Figma oferece uma ampla gama de recursos que permitem aos usuários criar layouts, protótipos interativos e colaborar em tempo real com suas equipes.</Text></View>
        <View style={styles.one}><Image source={Figma}/></View>
        <View style={styles.two}><Text style={styles.paragraph2}> Uma das principais vantagens do Figma é sua capacidade de funcionar em qualquer sistema operacional, já que é baseado em nuvem e acessível através de um navegador web.</Text></View>
        <View style={styles.one}><Image source={Figma}/></View>
        <View style={styles.two}><Text style={styles.paragraph2}>  Com o Figma, os designers podem criar designs responsivos, ajustando facilmente os elementos de interface para diferentes tamanhos de tela. </Text></View>
        </ScrollView>
      </View>
      <View style={styles.blue}>
<Pressable style={({pressed})=>[{backgroundColor: pressed ? 'white':'black',},styles.button,]}
        onPress={()=> Alert.alert('Click executado com sucesso!!!')}>
          <Text style={styles.paragraph2}>Pressione Aqui</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    paddingTop: '15%',
  },
  paragraph: {
    margin: 5,
    fontSize: 24,
    textAlign: 'center',
    color: '#0000ff',
  },
  paragraph2: {
    margin: 24,
    fontSize: 24,
    textAlign: 'center',
    color: '#000000',
  },
  blue: {
    flex: 1.5,
    height: '10%',
    width: '100%',
    backgroundColor: '#0000ff',
  },
  red: {
    flex: 9,
    height: '90%',
    backgroundColor: '#ff0000',
  },
  one: {
    height: '18%',
    backgroundColor: '#F08080',
    marginBottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  two: {
    height: '18%',
    backgroundColor: '#836FFF',
    marginBottom: 20,
  },
  button: {
    justifyContent: 'center',
    flex: 1,
    height: '10%',
    backgroundColor: '#0000ff',
  },
  photo: {
    height: '8%',
    width: '25%',
  },
});